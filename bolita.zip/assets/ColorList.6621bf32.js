const o=["#ee6055","#60d394","#aaf683","#ffd97d","#ff9b85"],f=["#9b5de5","#f15bb5","#fee440","#00bbf9","#00f5d4"];export{o as a,f as r};
