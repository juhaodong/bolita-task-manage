import{D as a}from"./index.65fbef77.js";const Y=[a().startOf("day").valueOf(),a().endOf("day").valueOf()];a().format("YYYY-MM-DD"),a().format("YYYY-MM-DD");export{Y as v};
