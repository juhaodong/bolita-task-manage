import{s as t}from"./index.65fbef77.js";const r={};function s(c,e){return null}const _=t(r,[["render",s]]);export{_ as default};
