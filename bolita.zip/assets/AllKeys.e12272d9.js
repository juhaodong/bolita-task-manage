const D=["DHL","DPD","UPS","GLA","GLS","UPA"];export{D as a};
