import"./index.65fbef77.js";import{f1 as r}from"./index.65fbef77.js";export{r as default};
