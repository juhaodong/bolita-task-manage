import{aR as r}from"./index.65fbef77.js";const a="OutWarehouseOffer",t=r({collectionName:a,init(e){return e},idPrefix:"OW"});export{t as O,a};
