import"./index.65fbef77.js";import{f0 as r}from"./index.65fbef77.js";export{r as default};
