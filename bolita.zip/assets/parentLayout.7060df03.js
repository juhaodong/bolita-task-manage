import{s as o,ab as r,o as t,y as n}from"./index.65fbef77.js";const c={};function s(a,_){const e=r("router-view");return t(),n(e)}const f=o(c,[["render",s]]);export{f as default};
